<?php
//****validasi apakah yang bukak panitia*****//
if($_SERVER['PHP_SELF']){
    if(!isset($_SESSION['panitia'])){    
        header('location: index.php');
    };
};
//****Perhitungan - Mumet deh*****//
sambung();
//******* Pilihan Pertama *********//
$ap=mysql_query("select * from biodata_siswa where jurusan1='AP'");
$ap=mysql_num_rows($ap);

$ak=mysql_query("select * from biodata_siswa where jurusan1='AK'");
$ak=mysql_num_rows($ak);

$pm=mysql_query("select * from biodata_siswa where jurusan1='PM'");
$pm=mysql_num_rows($pm);

$tkj=mysql_query("select * from biodata_siswa where jurusan1='TKJ'");
$tkj=mysql_num_rows($tkj);

$tei=mysql_query("select * from biodata_siswa where jurusan1='TEI'");
$tei=mysql_num_rows($tei);

$jumlah=$ap+$ak+$pm+$tkj+$tei;
//**PURA PURA MATI JIKA DATA KOSONG**//
if($jumlah=='0'){
    die("<script type='text/javascript'>alert('Data Kosong');</script>");
}
//******* Pilihan Kedua *********//

$ap2=mysql_query("select * from biodata_siswa where jkel='LAKI-LAKI'");
$ap2=mysql_num_rows($ap2);

$ak2=mysql_query("select * from biodata_siswa where jkel='PEREMPUAN'");
$ak2=mysql_num_rows($ak2);

$pm2=mysql_query("select * from biodata_siswa where jurusan2='PM'");
$pm2=mysql_num_rows($pm2);

$tkj2=mysql_query("select * from biodata_siswa where jurusan2='TKJ'");
$tkj2=mysql_num_rows($tkj2);

$tei2=mysql_query("select * from biodata_siswa where jurusan2='TEI'");
$tei2=mysql_num_rows($tei2);

$jumlah2=$ap2+$ak2+$pm2+$tkj2+$tei2;

//******* Pilihan Ketiga *********//

$ap3=mysql_query("select * from biodata_siswa where agama='MADRASAH'");
$ap3=mysql_num_rows($ap3);

$ak3=mysql_query("select * from biodata_siswa where agama='SEKOLAH'");
$ak3=mysql_num_rows($ak3);

$pm3=mysql_query("select * from biodata_siswa where jurusan2='PM'");
$pm3=mysql_num_rows($pm3);

$tkj3=mysql_query("select * from biodata_siswa where jurusan2='TKJ'");
$tkj3=mysql_num_rows($tkj3);

$tei3=mysql_query("select * from biodata_siswa where jurusan2='TEI'");
$tei3=mysql_num_rows($tei3);

$jumlah3=$ap3+$ak3+$pm3+$tkj3+$tei3;

?>
<table border='1' cellpadding='3' cellspacing='0' id='tbl_stat' width='100%' style='font-family: time news roman; font-size: 12;'>
    <tr>
        <td colspan='6'>
          <img src='../img/icon/stat.png' width='22' height='22'>   Statistik Pendaftar Tanggal :<b> <?php echo date('d-M-Y') ?></b>        </td>
    </tr>
    <tr>
        <td colspan='6' align='left'>
          <b>Total Peserta Valid: <?php echo $jumlah; ?> | Total Peserta Diterima: 0 | Kapasitas: 1000</b>        </td>
    </tr>
    <!-------Pilihan Pertama--------->
    <tr>
        <td colspan='6' align='center'><strong>ASAL SISWA CALON PESERTA DIDIK BARU</strong></td>
    </tr>
    <tr>
        <td align='center' width='331' class='tbl'>ASAL SISWA :</td>
        <td width="407" align='center' class='tbl'>Dari  Kec. Bangil</td>
  <td width="118" align='center' class='tbl'>
            Dari Kab. Pasuruan      </td>
  <td colspan="3" align='center' class='tbl'>Dari luar Kab. Pasuruan</td>
    </tr>
    <tr>
        <td align='center' class='tbl'>
            Jumlah        </td>
        <td align='center' class='sub'>
            <?php echo $ap; ?>        </td>
        <td align='center' class='sub'>
            <?php echo $ak; ?>        </td>
        <td colspan="3" align='center' class='sub'>
            <?php echo $pm; ?>        </td>
    </tr>
    <tr>
      <td align='center' class='tbl'>Prosentase</td>
<td align='center' class='sub'><?php echo substr(($ap/$jumlah)*100, 0, 4)."%"; ?></td>
      <td colspan="2" align='center' class='sub'><?php echo substr(($ak/$jumlah)*100, 0, 4)."%"; ?></td>
      <td width="409" align='center' class='sub'><?php echo substr(($pm/$jumlah)*100, 0, 4)."%"; ?></td>
    </tr>
    <tr>
        <td colspan='6' align='left'><div align="center"><img src='chart.php?ap=<?php echo $ap; ?>&tkj=<?php echo $tkj; ?>&pm=<?php echo $pm; ?>&tei=<?php echo $tei; ?>&ak=<?php echo $ak; ?>' width='150' height='150' align='middle' />
        </div>
          <table width="205" align="center" cellpadding='4' style='font-size: 12;'>
            <tr>
                <td width="191" style='background-color: #33ccff;' >Domisili dalam Kec. Bangil</td>
            </tr>
            <tr>
                <td style='background-color: #99cc33;' >Domisili dalam Kab. Pasuruan</td>
            </tr>
            <tr>
                <td style='background-color: #9933cc;' >Domisili di Luar Kab. Pasuruan</td>
            </tr> 
          </table>        </td>
    </tr>
     <!-------Pilihan Kedua--------->
    <tr>
        <td colspan='6' align='center'><strong>Jenis Kelamin Calon Peserta Didik</strong></td>
    </tr>
    <tr>
        <td align='center' width='331' class='tbl'>
            KETERANGAN</td>
        <td align='center' class='tbl'>LAKI-LAKI</td>
        <td colspan="4" align='center' class='tbl'>PEREMPUAN</td>
  </tr>
    <tr>
        <td align='center' class='tbl'>
            Jumlah        </td>
        <td align='center' class='sub'>
            <?php echo $ap2; ?>        </td>
        <td colspan="4" align='center' class='sub'>
            <?php echo $ak2; ?>        </td>
  </tr>
    <tr>
        <td align='center' class='tbl'>
            Prosentase        </td>
        <td align='center' class='sub'>
            <?php echo substr(($ap2/$jumlah2)*100, 0, 4)."%"; ?>        </td>
        <td colspan="4" align='center' class='sub'>
            <?php echo substr(($ak2/$jumlah2)*100, 0, 4)."%"; ?>        </td>
  </tr>
    <tr>
        <td colspan='6' align='left'>
            <div align="center"><img src='chart.php?ap=<?php echo $ap2; ?>&tkj=<?php echo $tkj2; ?>&pm=<?php echo $pm2; ?>&tei=<?php echo $tei2; ?>&ak=<?php echo $ak2; ?>' width='150' height='150' align='middle'>            </div>
            <table align="center" cellpadding='4' style='font-size: 12;'>
                <tr>
                    <td style='background-color: #33ccff;' >LAKI-LAKI</td>
                </tr>
                <tr>
                    <td style='background-color: #99cc33;' >PEREMPUAN</td>
                </tr> 
              </table>        </td>
    </tr>
     <!-------Pilihan KETIGA--------->
    <tr>
        <td colspan='6' align='center'><strong>JENIS ASAL SEKOLAH</strong></td>
    </tr>
    <tr>
        <td align='center' width='331' class='tbl'>
            KETERANGAN</td>
        <td align='center' class='tbl'>MADRASAH</td>
        <td colspan="4" align='center' class='tbl'>SEKOLAH DASAR</td>
  </tr>
    <tr>
        <td align='center' class='tbl'>
            Jumlah        </td>
        <td align='center' class='sub'>
            <?php echo $ap3; ?>        </td>
        <td colspan="4" align='center' class='sub'>
            <?php echo $ak3; ?>        </td>
  </tr>
    <tr>
        <td align='center' class='tbl'>
            Prosentase        </td>
        <td align='center' class='sub'>
            <?php echo substr(($ap3/$jumlah3)*100, 0, 4)."%"; ?>        </td>
        <td colspan="4" align='center' class='sub'>
            <?php echo substr(($ak3/$jumlah3)*100, 0, 4)."%"; ?>        </td>
  </tr>
    <tr>
        <td colspan='6' align='left'>
            <div align="center"><img src='chart.php?ap=<?php echo $ap3; ?>&tkj=<?php echo $tkj3; ?>&pm=<?php echo $pm3; ?>&tei=<?php echo $tei3; ?>&ak=<?php echo $ak3; ?>' width='150' height='150' align='middle'>            </div>
            <table align="center" cellpadding='4' style='font-size: 12;'>
                <tr>
                    <td style='background-color: #33ccff;' >MADRASAH IBTIDAIYAH</td>
                </tr>
                <tr>
                    <td style='background-color: #99cc33;' >SEKOLAH DASAR</td>
                </tr> 
              </table>        </td>
    </tr>

     <!---------------->
    <tr>
        <td colspan='6' style='font-size: 8;'>
         <br />* Mohon Refresh Halaman Setiap 5 Menit Sekali Untuk Melihat Update Data Terbaru.        </td>
    </tr>
</table>
