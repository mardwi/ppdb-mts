<?php
session_start();
include 'inti.php';
?>
<html>
<head><title>KARTU TES PPDB MTSN BANGIL</title>
<style type="text/css">
<!--
.style11 {font-size: 11px}
.style14 {font-size: 3px}
.style15 {font-size: 7px; }
.style16 {font-size: 12px}
-->
</style>
</head>
<body>
<table width="376" height="186" border="1" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center">
      <table width="378" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td height="58" align="center" valign="middle"><img src="../img/logobangil.jpg" width="47" height="47" align="top"></td>
            <td colspan="3" align="center" valign="middle">STATUS BERKAS DAN KELULUSAN</td>
          </tr>
          <tr>
            <td height="58" colspan="4" align="center" valign="middle"><table width="351" border="1" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="281" height="31"><div align="center"><span class="style14"><span class="style1"><span class="style11">
                    <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['nama'];
};
?>
                  </span></span></span></div></td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td width="89" rowspan="3" align="right" valign="top"><div align="center"><img src="../<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['foto'];
};

?>" alt="" width="76"height="97" align="middle"></div></td>
            <td width="129" height="31" valign="middle"><span class="style16">STATUS BERKAS</span></td>
            <td width="7" valign="middle"><span class="style16">:</span></td>
            <td width="153" valign="middle"><?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['verifikasi'];

};

?></td>
          </tr>
          <tr>
            <td height="34" valign="middle"><span class="style16">HASIL SELEKSI</span></td>
            <td valign="middle"><span class="style16"></span></td>
            <td valign="middle"><?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['status'];

};

?></td>
          </tr>
          <tr>
            <td height="57"><span class="style16"></span></td>
            <td><span class="style16"></span></td>
            <td valign="bottom"><span class="style11">panitia  PPDB MTsN </span></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
            <td valign="top"><span class="style16"></span></td>
            <td valign="top"><span class="style11">...........................................</span></td>
          </tr>
          </table>
    </div></td>
  </tr>
</table>
<p align="left" class="style15">&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>