<?php
session_start();
include 'inti.php';
?>
<html>
<head><title>KARTU TES PPDB MTSN BANGIL</title>
<style type="text/css">
<!--
.style11 {font-size: 11px}
.style13 {font-size: 14px}
.style14 {font-size: 3px}
.style15 {font-size: 7px; }
-->
</style>
</head>
<body>
<table width="376" height="186" border="1" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center">
      <table width="378" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td height="58" align="center" valign="middle"><div align="center">
                <p align="center"><img src="../img/logobangil.jpg" width="47" height="47" align="top"><br>
                </p>
            </div></td>
            <td colspan="3" align="center" valign="middle"><span class="style13">KARTU TES PPDB MTsN BANGIL PASURUAN<br>
              TAHUN PELAJARAN 2016-2017</span><span class="style14"><BR>
            ________________________________________________________________________________________________________________________________________________</span></td>
          </tr>
          <tr>
            <td width="79" rowspan="3" align="right" valign="top"><div align="center"><img src="../<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['foto'];
};

?>" alt="" width="68"height="84" align="middle"></div></td>
            <td width="90" valign="top"><span class="style11">NOMER REG<br>
              NAMA<br>
              SEKOLAH ASAL<br>
            ALAMAT</span></td>
            <td width="21" valign="top"><span class="style11">:<br>
              :<br>
              :<br>
              :<br>
            </span></td>
            <td width="188" valign="top"><span class="style11">
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['no_reg'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['nama'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['asal_sek'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['alamat'];
};
?>
              <br>
            </span></td>
          </tr>
          <tr>
            <td height="34">&nbsp;</td>
            <td>&nbsp;</td>
            <td valign="bottom"><span class="style11">
              <?php
echo "BANGIL, " . date("d-m-Y") . "<br>";
?></span></td>
          </tr>
          <tr>
            <td height="57">&nbsp;</td>
            <td>&nbsp;</td>
            <td valign="top"><span class="style11">panitia  PPDB MTsN BANGIL</span></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td valign="top">&nbsp;</td>
            <td valign="top">&nbsp;</td>
            <td valign="top"><span class="style11">...........................................</span></td>
          </tr>
          </table>
    </div></td>
  </tr>
</table>
<p align="left" class="style15">......................................................................................................................................................................................cut here!!</p>
<table width="376" height="186" border="1" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center">
      <table width="378" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
        <tr>
          <td height="58" align="center" valign="middle"><div align="center">
            <p align="center"><img src="../img/logobangil.jpg" width="47" height="47" align="top"><br>
            </p>
          </div></td>
          <td colspan="3" align="center" valign="middle"><span class="style13">KARTU DAFTAR KEHADIRAN TES PPDB MTSN BANGIL<br>
            TAHUN PELAJARAN 2016-2017</span><span class="style14"><BR>
              ________________________________________________________________________________________________________________________________________________</span></td>
        </tr>
        <tr>
          <td width="79" rowspan="3" align="right" valign="top"><div align="center"><img src="../<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['foto'];
};

?>" alt="" width="68"height="84" align="middle"></div></td>
          <td width="90" height="90" valign="top"><span class="style11">NOMER REG<br>
            NAMA<br>
            SEKOLAH ASAL<br>
            ALAMAT</span></td>
          <td width="21" valign="top"><span class="style11">:<br>
            :<br>
            :<br>
            :<br>
          </span></td>
          <td width="188" valign="top"><span class="style11">
            <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['no_reg'];
};
?>
            <br>
            <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['nama'];
};
?>
            <br>
            <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['asal_sek'];
};
?>
            <br>
            <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['alamat'];
};
?>
            <br>
          </span></td>
        </tr>
        <tr>
          <td height="34"><div align="center"><span class="style11">TES I</span></div></td>
          <td><div align="center"></div></td>
          <td valign="bottom"><p align="center" class="style11">TANDA TANGAN</p>
            <p align="center" class="style11">&nbsp;</p>
            <p align="center" class="style11">..........................................................</p></td>
        </tr>
        <tr>
          <td height="57"><div align="center"><span class="style11">TES II</span></div></td>
          <td><div align="center"></div></td>
          <td valign="bottom"><div align="center">
            <p class="style11">TANDA TANGAN</p>
            <p class="style11">&nbsp;</p>
            <p class="style11">............................................................</p>
          </div></td>
        </tr>
      </table>
    </div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>