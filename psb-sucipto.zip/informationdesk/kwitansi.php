<?php
session_start();
include 'inti.php';
?>
<html>
<head><title>KARTU TES PPDB MTSN BANGIL</title>
<style type="text/css">
<!--
.style11 {font-size: 11px}
.style13 {font-size: 14px}
.style14 {font-size: 3px}
.style15 {font-size: 7px; }
-->
</style>
</head>
<body>
<table width="842" height="186" border="1" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center">
      <table width="843" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td height="58" align="center" valign="middle"><div align="center">
                <p align="right"><img src="../img/logobangil.jpg" width="47" height="47" align="top"><br>
                </p>
            </div></td>
            <td colspan="3" align="center" valign="middle"><div align="left"><span class="style13">KWITANSI PEMBAYARAN PENDAFTARAN PPDB<BR>
              MADRASAH TSANAWIYAH NEGERI BANGIL<br>
              TAHUN PELAJARAN 2016-2017</span><span class="style14"><BR>
            ________________________________________________________________________________________________________________________________________________</span></div></td>
          </tr>
          <tr>
            <td width="237" rowspan="3" align="right" valign="top"><div align="center"><img src="../<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['foto'];
};

?>" alt="" width="68"height="84" align="middle"></div></td>
            <td width="138" valign="top"><span class="style11">NOMER REG<br>
              NAMA<br>
              SEKOLAH ASAL<br>
            ALAMAT</span></td>
            <td width="46" valign="top"><span class="style11">:<br>
              :<br>
              :<br>
              :<br>
            </span></td>
            <td width="422" valign="top"><span class="style11">
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['no_reg'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['nama'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['asal_sek'];
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['alamat'];
};
?>
              <br>
            </span></td>
          </tr>
          <tr>
            <td height="34">&nbsp;</td>
            <td>&nbsp;</td>
            <td valign="bottom"><span class="style11">
              <?php
echo "BANGIL, " . date("d-m-Y") . "<br>";
?></span></td>
          </tr>
          <tr>
            <td height="57">&nbsp;</td>
            <td>&nbsp;</td>
            <td valign="top"><span class="style11">panitia  PPDB MTsN BANGIL</span></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td valign="top">&nbsp;</td>
            <td valign="top">&nbsp;</td>
            <td valign="top"><span class="style11">...........................................</span></td>
          </tr>
          </table>
    </div></td>
  </tr>
</table>
<p align="left" class="style15">&nbsp;</p>
</body>
</html>