<?php
session_start();
include 'inti.php';
?>
<html>
<head><title>KARTU TES PPDB MTSN BANGIL</title>
<style type="text/css">
<!--
.style11 {font-size: 11px}
.style13 {font-size: 14px}
.style14 {font-size: 3px}
.style15 {font-size: 7px; }
-->
</style>
</head>
<body>
<table width="842" height="186" border="1" align="left" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center">
      <table width="843" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#000000">
          <tr>
            <td height="58" align="center" valign="middle"><img src="../img/logobangil.jpg" width="47" height="47" align="top"></td>
            <td colspan="3" align="center" valign="middle"><div align="left"><span class="style13">KWITANSI PEMBAYARAN PENDAFTARAN PPDB<br>
              MADRASAH TSANAWIYAH NEGERI BANGIL<br>
              TAHUN PELAJARAN 2016-2017</span><span class="style14"><br>
            ________________________________________________________________________________________________________________________________________________</span></div></td>
          </tr>
          <tr>
            <td height="35" align="center" valign="middle"><div align="center" class="style11">
                <p align="center"><br>
                </p>
            </div></td>
            <td colspan="3" align="center" valign="middle"><div align="left" class="style11">TELAH DITERIMA PEMBAYARAN DENGAN NOMER REG. 
                <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo $i['no_reg'];
};
?>
            ATAS NAMA:</div></td>
          </tr>
          <tr>
            <td width="112" rowspan="3" align="right" valign="top"><div align="center" class="style11"><img src="../<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $foto;
$pilih=mysql_query("select * from siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);
echo $i['foto'];
};

?>" alt="" width="68"height="84" align="middle"></div></td>
            <td width="98" valign="top"><span class="style11">              NAMA<br>
              SEKOLAH ASAL<br>
ALAMAT<br>
NOMINAL<br> 
STATUS
</span></td>
            <td width="12" valign="top"><span class="style11">:<br>
              :<br>
              :<br>
              :<br>
              :<br>
            </span></td>
            <td width="621" valign="top"><span class="style11">
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo strtoupper( $i['nama']);
};
?>
              <br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo strtoupper( $i['asal_sek']);
};
?>
<br>
<?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo strtoupper( $i['alamat']);
};
?>
<br>
              600.000 (ENAM RATUS RIBU RUPIAH)<br>
              <?php
sambung();

if($_GET['lihat']){
$nomer=mysql_real_escape_string($_GET['lihat']);
//echo $nomer;
$pilih=mysql_query("select * from biodata_siswa where no_reg='$nomer'");
$i=mysql_fetch_array($pilih);

echo strtoupper( $i['bayar']);
};
?>
<br>
            </span></td>
          </tr>
          <tr>
            <td height="34"><span class="style11"></span></td>
            <td><span class="style11"></span></td>
            <td valign="bottom"><span class="style11">
              <?php
echo "BANGIL, " . date("d-m-Y") . "<br>";
?></span></td>
          </tr>
          <tr>
            <td height="57"><span class="style11"></span></td>
            <td><span class="style11"></span></td>
            <td valign="top"><span class="style11">PANITIA   PPDB MTsN BANGIL<br>
            TTD</span></td>
          </tr>
          <tr>
            <td><span class="style11"></span></td>
            <td valign="top"><span class="style11"></span></td>
            <td valign="top"><span class="style11"></span></td>
            <td valign="top"><span class="style11">...........................................</span></td>
          </tr>
          </table>
    </div></td>
  </tr>
</table>
<p align="left" class="style15">&nbsp;</p>
<p align="left" class="style15">&nbsp;</p>
<p align="left" class="style15">&nbsp;</p>
</body>
</html>