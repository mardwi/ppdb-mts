<?php
session_start();
if(!isset($_SESSION['panitia2'])){
   header('location: index.php'); 
}else{
include 'inti.php';
loging($_SESSION['panitia2']." Download File Report Exel");
exel();
};
?>