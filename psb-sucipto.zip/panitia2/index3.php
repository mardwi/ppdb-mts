<?php
session_start();
include 'inti.php';
//keluar//
if($_GET['keluar']=='yo'){ 
    sambung();
    $nama=$_SESSION['panitia2'];
    mysql_query("update panitia2 set sedang_login='tidak' where nama='$nama'");
    unset($_SESSION['panitia2']);
    loging($nama." Log Out");
}
//**************Hapus Record Daftar Peserta *************//
if($_GET['hapus']){
    sambung();    
    $noreg=mysql_real_escape_string($_GET['hapus']);
    $hps=mysql_query("delete from biodata_siswa where no_reg='$noreg'");
    if($hps){
        loging($_SESSION['panitia2'].", Menghapus ".$noreg);
        echo "<script type='text/javascript'>alert('Data Sudah Dihapus !')</script>";
        echo "<script type='text/javascript'>window.location='index3.php?hal=list'</script>";
    }
 }
////////////////
//**************Luluskan Daftar Peserta *************//
if($_GET['update']){
    sambung();    
    $noreg=mysql_real_escape_string($_GET['update']);
    $upt=mysql_query("update siswa SET status='LULUS' where no_reg='$noreg'");
    if($upt){
        loging($_SESSION['panitia2'].", Mengupdate ".$noreg);
        echo "<script type='text/javascript'>alert('Data Sudah Diupdate !')</script>";
        echo "<script type='text/javascript'>window.location='index3.php?hal=list'</script>";
    }
 }
////////////////
//**************Verifikasikan Daftar Peserta *************//
if($_GET['verifikasi']){
    sambung();    
    $noreg=mysql_real_escape_string($_GET['verifikasi']);
    $upt=mysql_query("update siswa SET verifikasi='SUDAH VERIFIKASI' where no_reg='$noreg'");
    if($upt){
        loging($_SESSION['panitia2'].", Memverifikasi ".$noreg);
        echo "<script type='text/javascript'>alert('Data Sudah diverifikasi !')</script>";
        echo "<script type='text/javascript'>window.location='index3.php?hal=list'</script>";
    }
 }
//**************Pembayaran Peserta *************//
if($_GET['bayar']){
    sambung();    
    $noreg=mysql_real_escape_string($_GET['bayar']);
    $upt=mysql_query("update biodata_siswa SET bayar='Sudah Bayar' where no_reg='$noreg'");
    if($upt){
        loging($_SESSION['panitia'].", Memverifikasi ".$noreg);
        echo "<script type='text/javascript'>alert('Alhamdulillah sudah bayar !')</script>";
        echo "<script type='text/javascript'>window.location='index3.php?hal=list'</script>";
    }
 }
////////////////
//**************Pembayaran Peserta batal*************//
if($_GET['gakbayar']){
    sambung();    
    $noreg=mysql_real_escape_string($_GET['gakbayar']);
    $upt=mysql_query("update biodata_siswa SET bayar='Belum Lunas' where no_reg='$noreg'");
    if($upt){
        loging($_SESSION['panitia'].", Menyatakan belum membayar An. ".$noreg);
        echo "<script type='text/javascript'>alert('Alhamdulillah belum bayar !')</script>";
        echo "<script type='text/javascript'>window.location='index3.php?hal=list'</script>";
    }
 }
////////////////
if(!isset($_SESSION['panitia2'])){
    header('location: index.php?login=dulu');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <title>Halaman Admin PPDB MTSN Bangil</title>

    <script type="text/javascript" src="script.js"></script>

    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
    <style type="text/css">
<!--
.style1 {font-size: 12px}
.style2 {font-size: 9px; }
.style4 {font-size: 6px; }
-->
    </style>
</head>
<body>
<div id="art-page-background-simple-gradient">
    </div>
    <div id="art-main">
    <div class="art-Sheet">
<div class="art-Sheet-tl"></div>
            <div class="art-Sheet-tr"></div>
            <div class="art-Sheet-br"></div>
            <div class="art-Sheet-tc"></div>
            <div class="art-Sheet-cl"></div>
            <div class="art-Sheet-cr"></div>
            <div class="art-Sheet-cc"></div>
            <div class="art-Sheet-body">
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                		<li>
                			<a href="#" class=" active"><span class="l"></span><span class="r"></span><span class="t">Home</span></a>
                		</li>
                		<li>
                			<a href="#"><span class="l"></span><span class="r"></span><span class="t">Menu Item</span></a>
                			<ul>
                				<li><a href="#">Menu Subitem 1</a>
                					<ul>
                						<li><a href="#">Menu Subitem 1.1</a></li>
                						<li><a href="#">Menu Subitem 1.2</a></li>
                						<li><a href="#">Menu Subitem 1.3</a></li>
                					</ul>
                				</li>
                				<li><a href="#">Menu Subitem 2</a></li>
                				<li><a href="#">Menu Subitem 3</a></li>
                			</ul>
                		</li>		
                		<li>
                			<a href="#"><span class="l"></span><span class="r"></span><span class="t">About</span></a>
                		</li>
                	</ul>
                </div>
                <div class="art-Header">
                    <div class="art-Header-jpeg"></div>
                    <div class="art-Logo">
                        <h1 id="name-text" class="art-Logo-name"><a href="#">ppdb mtSn bangil</a></h1>
                        <div id="slogan-text" class="art-Logo-text">pasuruan jawa timur</div>
                    </div>
                </div>
                <div class="art-contentLayout"><table border='0' width='100%'>
            <tr>
                <td width='25'><a href='index3.php?hal=list' title='Kembali Ke halaman Utama'><img src='../img/icon/omah.png' width='22' height='22'></a></td>
              <td width='25'><a href='exel.php' title='Unduh Hasil Pendaftaran Sementara'><img src='../img/icon/unduh.svg' width='22' height='22'></a></td>
                <td width='25'><a onclick='window.location="?hal=stat"' href='#' title='Lihat Statistik Pendaftaran'><img src='../img/icon/stat.png' width='22' height='22'></a></td>
                <td width='25'><a onclick='window.location="?hal=pengumuman"' href='#' title='Pengumuman ke Siswa'><img src='../img/icon/mic.png' width='22' height='22'></a></td>
                <td width='25'><a onclick='window.location="?hal=list"' href='#' title='Lihat Pendaftar'><img src='../img/icon/wong.png' width='22' height='22'></a></td>
                <td width='25'><a onclick='window.location="?hal=log"' href='#' title='Lihat Jejak website'><img src='../img/icon/jejak.png' width='22' height='22'></a></td>
                <td width='25'>&nbsp;</td>
              <td width='25'></td>
                <td width='25'></td>
                <td width='25'><a href='<?php echo $_SERVER['REQUEST_URI']; ?>' title='Refresh Halaman'><img src='../img/icon/refresh.png'></a></td>
                <td width='50' id='user'>
                <!-- iki bagian pinggir tengen dewe -->
                 <a href='#' onclick='window.location="?keluar=yo"' title='Keluar'>Keluar <img src='../img/icon/lawang.png' width='16' height='16'></a>                <a href='#' onclick="window.open('pesan.php?mode=lihat','popupwindow','scrollbars=yes, width=400,height=500');"><br />
                 Pesan masuk
                 <img src='../img/icon/amplop.png' width='16' height='16' />
                 <?php if($belum > '0'){ echo "( ".$belum." )</b>";} ?>
                 </a></td>
            </tr>
        </table>
<div class="art-sidebar1"></div>

                    <div class="art-BlockContent">
                      <table id='m_kiri' width='885' height='100%'>
                        <tr>
                          <td><img src='../img/icon/chat.png' width='16' height='16' />
                              <?php hari($sekarang); echo " ".$_SESSION['panitia2']." !"; ?>
                            | <img src='../img/icon/cal.png' width='16' height='16' /> <?php echo date('d M Y'); ?> | <img src='../img/icon/jam.png' width='16' height='16' /><b id='jam'>
                            <?php waktu(); ?>
                            | 
                            <?php if($belum > '0'){ echo "<b>";} ?>
                            </b></td>
                        </tr>
                        <tr>
                          <td><a href='#' onclick="window.open('pesan.php?mode=lihat','popupwindow','scrollbars=yes, width=400,height=500');"></a></td>
                        </tr>
                        <tr>
                          <td>Anda masuk sebagai                  <img src='../img/icon/plontos.png' width='16' height='16' title='Anda login sebagai <?php echo $_SESSION["panitia2"]; ?>'><b style='color: blue; text-shadow: 0 0 5px;'>&nbsp; <?php echo $_SESSION['panitia2']; ?></b>&nbsp;&nbsp;
| <a href='#' onclick="window.open('kunci.php','popupwindow','scrollbars=no, width=345,height=300');"><img src='../img/icon/kunci.png' width='16' height='16' /> Ganti Password</a></td><td><a href='#' onclick="window.open('kunci.php','popupwindow','scrollbars=no, width=345,height=300');"></a></td>
                        </tr>
                        <tr>
                          <?php
            sambung();
            $pnt=$_SESSION['panitia2'];
            $asek=mysql_query("select * from pesan where kepada='$pnt' and dibaca='0'");
            $belum=mysql_num_rows($asek);
            ?>
                          <td height="17"><hr />
                          <a href='#' onclick="window.open('pesan.php?mode=lihat','popupwindow','scrollbars=yes, width=400,height=500');"></a></td>
                        </tr>
                        <tr>
                          <td><a href='#' onclick="window.open('kunci.php','popupwindow','scrollbars=no, width=345,height=300');"></a></td>
                        </tr>
                      </table>
                    </div>
                    <!-- ISi Tengah -->
            <?php
            /////////////// Jika halaman Log /////////
                if($_GET['hal']=='log'){
                    sambung();
                    $q=mysql_fetch_array(mysql_query("select file_log from sistem where id='1'"));
                    echo "<table border='0' width='100%' align='center' style='font-size: 12px;'><tr><td colspan='3'><img src='../img/icon/jejak.png' width='22' height='22'>Log Statistik Website - Jejak Aktifitas website</td><tr>";
                    echo "<tr><td width='50'>&nbsp;</td><td>";
                    buka_log("log/".$q['file_log']);
                    echo "</td>";
                    echo "</table>";
                    putus();
                };
            ////*********** Jika halaman Log ***********//
            //*********** Jika halaman statistik ***********///
                if($_GET['hal']=='stat'){
                    include 'statistik.php';
                };
            ///*********** Jika halaman statistik ***********///
             ///*********** Jika halaman pengumuman ***********///
                if($_GET['hal']=='pengumuman'){
                    sambung();
                    if($_POST['konten']){
                        $umum=mysql_real_escape_string($_POST['konten']);
                        $exe=mysql_query("update sistem set anoun='$umum' where id='1'");
                        if ($exe){
                            loging($_SESSION['panitia2']." Mengubah Pengumuman.");
                            echo "<script type='text/javascript'>alert('Berhasil di Umumkan');</script>";
                        }
                    }
                    //--------untuk melihat pengumuman--------//
                    $sam=mysql_query("select anoun from sistem");
                    $last=mysql_fetch_array($sam);
                    ?>
                    <br /><form action='<?php echo $_SERVER['REQUEST_URI']; ?>' method='post'>
                    <table border='1' cellspacing='0' cellpadding='3' width='100%'>
                        <tr>
                            <td><img src='../img/icon/mic.png' width='22' height='22'> Pengumuman</td>
                        </tr>
                        <tr>
                            <td width='100%'>
                                <textarea name="konten" rows="4" cols="30" style="margin-top: 2px; margin-bottom: 2px; height: 68px; margin-left: 2px; margin-right: 2px; width: 671px; "><?php echo $last['anoun']; ?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td><input type='submit' value='Umumkan'></td>
                        </tr>
                    </table>
                    </form>
                    <p>
                      <?php
                };
            //*********** Jika halaman pengumuman ***********//
             //*********** Jika halaman pendaftar ***********//
                if($_GET['hal']=='list'){
                    sambung();
                        //keperluan halaman next dll
                        $bts= 30;
                        $hal = $_GET['no'];
                        if (!isset($hal)){
                            $mulai=0;
                            }else{
                            $mulai= $hal * $bts;
                        };
                    $sql=@mysql_query("select * from biodata_siswa order by id DESC");
                    $jdt=mysql_num_rows($sql);
                    $jhal=ceil($jdt/$bts);
                    $daftar=mysql_query("select nama, no_reg, asal_sek, kunci, alamat, tahun, bayar from biodata_siswa order by no_reg ASC limit $mulai, $bts");
                    
                    ?> 
                      <img src='../img/icon/wong.png' width='22' height='22' /> <b>Daftar Peserta PPDB Online</b> | <span class="style1">Jumlah Total: <?php echo $jdt; ?></span><br />
                    </p>
                    <table width='100%' border='1' cellpadding='3' cellspacing='0' bordercolor="#666666" id='daftar' style='font-size: 11px;'>
                      <tr>
                        <td colspan='9'>&nbsp;</td>
                      </tr>
                      <tr>
                        <th width='95'><div align="center"><span class="style2">NOMOR REG</span></div></th>
                        <th width='146'><div align="center"><span class="style2">NAMA</span></div></th>
                        <th width='76'><div align="center"><span class="style2">BAYAR</span></div></th>
                        <th width='430'><div align="center"><span class="style2">ALAMAT</span></div></th>
                        <th width='86'><div align="center" class="style4">STATUS</div></th>
                        <th width='68'><div align="center" class="style4">VERIFIKASI</div></th>
                        <th width='87'><div align="center" class="style4">LULUSKAN</div></th>
                        <th width='140'><div align="center" class="style4">PEMBAYARAN</div></th>
                        <th width='85'><div align="center" class="style4">HAPUS</div></th>
                        <th width="5">&nbsp;</th>
                      </tr>
                      <?php
                        while ($dt=mysql_fetch_array($daftar)){
                            $id=$dt['no_reg'];
                            //echo $dt['no_reg'];
                            echo "
                            <tr>                           
                            <td width='100'>
                                ".$dt['no_reg']."</td>
                                <td width='200'>".$dt['nama']."</td>
                                <td width='75'>".$dt['bayar']."</td>
                                <td width='200'>".$dt['alamat']."</td>
                                <td width='75'><center><a title='Status Calon' onclick=\"window.open('status.php?lihat=".$dt['no_reg']."','popupwindow','scrollbars=yes, width=450,height=300');\" href='#'><img src='../img/icon/status.png' width='30' height='30'></center></a></td>
                                <td width='75'><center><a title='Verifikasi Data' href='index3.php?verifikasi=".$dt['no_reg']."' onclick='return confirm(\"Yakin sudah lengkap?\"); '><img src='../img/icon/kartu.png' width='25' height='25'></center></a></td>
                                <td width='75'><center><a title='Luluskan Peserta' href='index3.php?update=".$dt['no_reg']."' onclick='return confirm(\"Yakin Dia Lulus?\"); '><img src='../img/icon/2.png' width='25' height='25'></center></a></td>
                                <td width='75'><center><a title='Bayar Administrasi' href='index3.php?bayar=".$dt['no_reg']."' onclick='return confirm(\"Yakin sudah terima uangnya?\"); '><img src='../img/icon/cek.png' width='25' height='25'>|<a title='Gagalkan pembayaran Administrasi' href='index3.php?gakbayar=".$dt['no_reg']."' onclick='return confirm(\"Yakin gagalkan pembayaran?\"); '><img src='../img/icon/ceko.png' width='25' height='25'></center></a></td>
                                <td width='75'><center><a title='Hapus Peserta' href='index3.php?hapus=".$dt['no_reg']."' onclick='return confirm(\"Yakin Dihapus?\"); '><img src='../img/icon/hapus.png' width='25' height='25'></center></a>
</td>
                            </tr>                            
                            ";
                        };
                        ?>
                      <tr>
                        <td colspan='9'><div align="center"><a href='?hal=list&no=<?php echo max($hal-1, 0); ?>'>PREV</a> | <a href='?hal=list&<?php echo "no=".min($hal+1, $jhal-1); ?>'> NEXT</a> </div></td>
                      </tr>
                    </table>
                    <?php };
            //*********** Jika halaman pendaftar ***********//
            ?>
                    <!-- ISi Tengah -->
                    </td>
                    </tr>
<tr>
        <td colspan='5' style='font-size: 10px;' id='kaki'>Copyright &copy; <?php echo date('Y'); ?> MTSN BANGIL</td>
    </tr>
</table>
</body>
</html> 
              </div>
                <div class="cleared"></div><div class="art-Footer">
                    <div class="art-Footer-inner">
                        <a href="#" class="art-rss-tag-icon" title="RSS"></a>
                        <div class="art-Footer-text">
                            <p><a href="#">Contact Us</a> | <a href="#">Terms of Use</a> | <a href="#">Trademarks</a>
                                | <a href="#">Privacy Statement</a><br />
                                Copyright &copy; 2009 ---. All Rights Reserved.</p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
        		<div class="cleared"></div>
            </div>
        </div>
        <div class="cleared"></div>
        <p class="art-page-footer"><a href="http://webjestic.net/templates/">CSS Template</a> designed by webJestic.NET</p>
    </div>
    
</body>
</html>
